# LET'S TALK — Hosting Guide (v6)

## What's in this build

- **Auth**: email/password (Firebase Auth) — `pages/login.html`, `pages/signup.html`
- **Home + tabs**: Chats, Status, Calls, Groups
- **1:1 chat**: text/media/voice notes, reply (swipe or long-press), reactions, forward, delete-for-me / delete-for-everyone, read receipts, typing, last seen, `@ai` inline bot
- **Status**: text / image / video, viewers list, replies, reactions, reshare, delete-own (24h TTL)
- **Groups**: create, member list, admin promote/demote, add/remove, only-admins-post toggle, exit, delete (by creator)
- **Calls**: 1:1 voice + video via WebRTC (Firebase RTDB signaling), call history with missed/incoming/outgoing
- **LET'S TALK AI**: Gemini-powered assistant (`pages/ai-chat.html`) + `@ai` mention inside any chat
- **Settings**: profile, theme, notifications, privacy, clear chats

---

## 1. Deploy the frontend (`public/`)

Any static host works (Firebase Hosting, Netlify, Vercel, Cloudflare Pages, GitHub Pages).

### Firebase Hosting (recommended)

```bash
npm install -g firebase-tools
firebase login
firebase init hosting          # public dir = public, single-page = no
firebase deploy --only hosting
```

## 2. Deploy the AI server (`server/`)

The Node server proxies `@ai` and `pages/ai-chat.html` to Google Gemini.

```bash
cd server
npm install
# Set environment variables in your host (Render, Railway, Fly.io, etc.):
#   GEMINI_API_KEY = <your Gemini key>
#   PORT           = 3000
#   SERVE_STATIC   = 1   (optional: serves /public from same origin)
npm start
```

Once deployed, tell the frontend where to reach the AI:

In `public/index.html` (or anywhere loaded before `ai-mention.js` / `ai-chat.js`) add:
```html
<script>window.LT_AI_URL = "https://your-ai-server.example.com/api/chat";</script>
```

If you set `SERVE_STATIC=1` and host the frontend from the same Node server, no override is needed (`/api/chat` works relative).

## 3. Configure Firebase (Realtime Database + Auth + Storage)

The project ships pointing at the demo Firebase config in `public/js/firebase-config.js`. **Replace it with your own** for production.

### Realtime Database rules (paste into Firebase Console → Realtime Database → Rules)

```json
{
  "rules": {
    "users":      { ".read": "auth != null", "$uid": { ".write": "auth.uid == $uid || $uid == 'ai-bot'" } },
    "status":     { ".read": "auth != null", "$uid": { ".write": "auth.uid == $uid" } },
    "userChats":  { "$uid": { ".read": "auth.uid == $uid", ".write": "auth != null" } },
    "userChatState": { "$uid": { ".read": "auth.uid == $uid", ".write": "auth.uid == $uid" } },
    "messages":   { "$chat": { ".read": "auth != null", ".write": "auth != null" } },
    "typing":     { "$chat": { ".read": "auth != null", "$uid": { ".write": "auth.uid == $uid" } } },
    "typingGroups": { "$gid": { ".read": "auth != null", "$uid": { ".write": "auth.uid == $uid" } } },
    "groups":     { ".read": "auth != null", "$gid": { ".write": "auth != null" } },
    ".info":      { ".read": "auth != null" },
    "calls":      { "$uid": { ".read": "auth.uid == $uid", ".write": "auth != null" } },
    "incoming":   { "$uid": { ".read": "auth.uid == $uid", ".write": "auth != null" } },
    "rtc":        { "$callId": { ".read": "auth != null", ".write": "auth != null" } }
  }
}
```

### Storage rules

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} { allow read, write: if request.auth != null; }
  }
}
```

## 4. Calls behind NAT (optional)

WebRTC uses Google STUN by default. For users on restrictive networks (mobile data, corporate Wi-Fi) add a TURN server (Twilio, Metered, Xirsys, coturn). Before any page that uses calls, set:

```html
<script>
  window.LT_TURN = [
    { urls: "turn:turn.example.com:3478", username: "USER", credential: "PASS" }
  ];
</script>
```

## 5. Hardening checklist for production

- Replace the demo `firebaseConfig` and tighten the rules above to match your data model.
- Add Firestore/RTDB indexes if you scale (e.g. `userChats` time index).
- Restrict Gemini API key by HTTP referrer in Google Cloud Console.
- Enable Firebase App Check.
- Configure CORS on the AI server to only your domain.

---

## Known scaffolding (not magic — what you should know)

- **Group calls**: not in v6; only 1:1 voice/video.
- **End-to-end encryption**: not implemented. Messages live in Firebase RTDB in plaintext.
- **Push notifications when app is closed**: requires FCM Web Push setup (service worker + VAPID key) — not wired here.
- **Status views by exactly the audience you select**: stored on `status/{uid}/{statusId}.views`. The privacy gate ("everyone" vs "contacts") is enforced client-side; tighten in rules for strict privacy.
