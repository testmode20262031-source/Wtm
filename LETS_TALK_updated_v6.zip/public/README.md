# LET'S TALK, TALK 2 ME

Vanilla HTML/CSS/JS WhatsApp-style web app using Firebase (Auth + Realtime Database + Storage).

## Setup
1. Put your images in `assets/`:
   - `assets/logo.png`
   - `assets/splash-bg.png`
2. In Firebase Console enable:
   - Authentication → Email/Password
   - Realtime Database (rules: authenticated read/write)
   - Storage (rules: authenticated read/write)
3. Open `index.html` in a browser (or serve with `npx serve`).

## File map
- `index.html` – Splash
- `pages/login.html` – Login (email/password)
- `pages/signup.html` – Sign up
- `pages/home.html` – Main shell (Chats, Status, Calls, Groups tabs)
- `pages/chat.html` – Chat room (text/audio/media, reactions, forward, delete)
- `pages/contacts.html` – Contacts
- `pages/groups.html` – Groups list/create
- `pages/settings.html` – Settings
- `pages/profile.html` – Edit my profile (name, bio, picture, business DP)
- `pages/view-profile.html` – View another member

JS shared:
- `js/firebase-config.js` – Firebase init
- `js/auth-guard.js` – Redirects if not logged in
- `js/presence.js` – Online/last-seen
