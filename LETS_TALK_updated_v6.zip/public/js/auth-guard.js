// Redirect to login if not authenticated. Include AFTER firebase-config.js
auth.onAuthStateChanged(user => {
  if (!user) {
    if (!location.pathname.endsWith('login.html') &&
        !location.pathname.endsWith('signup.html')) {
      location.href = 'login.html';
    }
  }
});
