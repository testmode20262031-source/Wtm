// call.js — drives the call screen, uses LTRTC
const p = new URLSearchParams(location.search);
const mode = p.get("mode") || "out";         // "out" | "in"
const peerUid = p.get("uid");
const kind = p.get("kind") || "voice";       // "voice" | "video"
let callId = p.get("callId") || (mode==="out" ? db.ref().push().key : null);

const peerNameEl = document.getElementById("peerName");
const peerAvatarEl = document.getElementById("peerAvatar");
const peerStatusEl = document.getElementById("peerStatus");
const timerEl = document.getElementById("timer");
const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");
const remoteAudio = document.getElementById("remoteAudio");
const btnMute = document.getElementById("btnMute");
const btnCam  = document.getElementById("btnCam");
const btnSpk  = document.getElementById("btnSpk");
const btnEnd  = document.getElementById("btnEnd");
const btnAccept = document.getElementById("btnAccept");

if (kind !== "video") localVideo.style.display = "none";

let startedAt = 0, tickT = null, me = null;

function logCall(direction, durationSec, status) {
  if (!me || !peerUid) return;
  const dur = `${String(Math.floor(durationSec/60)).padStart(2,"0")}:${String(durationSec%60).padStart(2,"0")}`;
  const t = Date.now();
  db.ref("calls/" + me.uid + "/" + callId).set({
    peer: peerUid, kind, direction, time: t, duration: dur, status
  });
  db.ref("calls/" + peerUid + "/" + callId).set({
    peer: me.uid, kind,
    direction: direction === "out" ? (status==="missed"?"missed":"in") : "out",
    time: t, duration: dur, status
  });
}

function startTimer() {
  startedAt = Date.now();
  tickT = setInterval(() => {
    const s = Math.floor((Date.now()-startedAt)/1000);
    timerEl.textContent = `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;
  }, 500);
}

async function loadPeer() {
  const snap = await db.ref("users/" + peerUid).once("value");
  const u = snap.val() || {};
  peerNameEl.textContent = u.name || "Unknown";
  if (u.photoURL) peerAvatarEl.innerHTML = `<img src="${u.photoURL}">`;
  else peerAvatarEl.textContent = (u.name || "?")[0].toUpperCase();
}

btnMute.onclick = () => { const m = LTRTC.toggleMute(); btnMute.classList.toggle("on", m); };
btnCam.onclick  = () => { const off = LTRTC.toggleCam(); btnCam.classList.toggle("on", off); };
btnSpk.onclick  = () => btnSpk.classList.toggle("on");
btnEnd.onclick  = () => hangup("ended");

function hangup(status) {
  if (tickT) clearInterval(tickT);
  const dur = startedAt ? Math.floor((Date.now()-startedAt)/1000) : 0;
  LTRTC.endCall();
  if (me) logCall(mode === "out" ? "out" : "in", dur, status || (dur ? "ended" : "missed"));
  setTimeout(() => history.back(), 400);
}

auth.onAuthStateChanged(async user => {
  if (!user) return;
  me = user;
  await loadPeer();

  if (mode === "out") {
    peerStatusEl.textContent = "Ringing…";
    try {
      await LTRTC.startCall({
        callId, peerUid, myUid: me.uid, kind,
        localVideo, remoteVideo, remoteAudio,
        onState: st => {
          if (st === "connected" || st === "connected-answer") {
            peerStatusEl.textContent = "Connected";
            if (!startedAt) startTimer();
          } else if (st === "disconnected" || st === "failed" || st === "closed") {
            hangup("ended");
          }
        }
      });
      // Auto-cancel after 30s if not answered
      setTimeout(() => { if (!startedAt) hangup("missed"); }, 30000);
    } catch (e) {
      alert("Could not start call: " + (e.message||e));
      hangup("missed");
    }
  } else {
    // Incoming — show Accept button
    btnAccept.hidden = false;
    btnEnd.title = "Decline";
    peerStatusEl.textContent = "Incoming call…";
    btnAccept.onclick = async () => {
      btnAccept.hidden = true;
      try {
        await LTRTC.acceptCall({
          callId, myUid: me.uid,
          localVideo, remoteVideo, remoteAudio,
          onState: st => {
            if (st === "connected") {
              peerStatusEl.textContent = "Connected";
              if (!startedAt) startTimer();
            } else if (st === "disconnected" || st === "failed" || st === "closed") {
              hangup("ended");
            }
          }
        });
      } catch (e) {
        alert("Could not accept call: " + (e.message||e));
        hangup("ended");
      }
    };
  }
});

window.addEventListener("beforeunload", () => { try { LTRTC.endCall(); } catch(e){} });
