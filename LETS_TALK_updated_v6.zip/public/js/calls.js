// CALLS.JS — call history + initiating real WebRTC calls (via call.html)
const callList = document.getElementById("callList");
const fabCall  = document.getElementById("fabCall");
const searchToggle = document.getElementById("searchToggle");
const searchBar    = document.getElementById("searchBar");
const searchInput  = document.getElementById("searchInput");

if (searchToggle) searchToggle.onclick = () => {
  searchBar.hidden = !searchBar.hidden;
  if (!searchBar.hidden) searchInput.focus();
};
if (searchInput) searchInput.oninput = e => {
  const q = e.target.value.toLowerCase();
  callList.querySelectorAll(".list-item").forEach(it=>{
    it.style.display = (it.dataset.search||"").includes(q) ? "" : "none";
  });
};
if (fabCall) fabCall.onclick = () => location.href = "contacts.html?action=call";

const userCache = {};
function getUser(uid){
  if (userCache[uid]) return Promise.resolve(userCache[uid]);
  return db.ref("users/"+uid).once("value").then(s=>{userCache[uid]=s.val()||{};return userCache[uid];});
}
function avatarHTML(u){
  if (u && u.photoURL) return `<img src="${u.photoURL}" alt="">`;
  return ((u&&u.name)||"?")[0].toUpperCase();
}
function fmtTime(t){
  if (!t) return "";
  const d = new Date(t), today = new Date();
  if (d.toDateString()===today.toDateString())
    return "Today, "+d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
  const y = new Date(today); y.setDate(y.getDate()-1);
  if (d.toDateString()===y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([],{day:"numeric",month:"short"});
}

function startCall(peerUid, kind){
  location.href = `call.html?mode=out&uid=${peerUid}&kind=${kind||"voice"}`;
}
window.startCall = startCall;

auth.onAuthStateChanged(user => { if (user) loadCalls(user); });

function loadCalls(user){
  db.ref("calls/"+user.uid).orderByChild("time").limitToLast(100)
    .on("value", async snap => {
      const all = snap.val() || {};
      const items = Object.entries(all).sort((a,b)=>(b[1].time||0)-(a[1].time||0));
      callList.innerHTML = "";
      if (!items.length){
        callList.innerHTML = `<div class="empty">No calls yet.<br>Tap the 📞 button to start one.</div>`;
        return;
      }
      for (const [id, c] of items){
        const u = await getUser(c.peer);
        const dir = c.direction || "out";
        const isMissed = dir === "missed";
        const ico = isMissed ? "↙ missed" : dir==="in" ? "↙ incoming" : "↗ outgoing";
        const kindIco = c.kind==="video" ? "🎥" : "📞";
        const it = document.createElement("div");
        it.className = "list-item";
        it.dataset.search = ((u.name||"")+" "+(c.kind||"")).toLowerCase();
        it.innerHTML = `
          <div class="avatar">${avatarHTML(u)}</div>
          <div class="meta">
            <div class="name"><span style="${isMissed?'color:#e74c3c':''}">${u.name||"Unknown"}</span><span class="time">${fmtTime(c.time)}</span></div>
            <div class="call-type"><span class="ico ${dir}">${ico}</span> · ${c.duration||"—"}</div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="call-act" title="Voice call" data-k="voice">📞</button>
            <button class="call-act" title="Video call" data-k="video">🎥</button>
          </div>`;
        it.querySelectorAll(".call-act").forEach(b => {
          b.onclick = ev => { ev.stopPropagation(); startCall(c.peer, b.dataset.k); };
        });
        it.onclick = () => location.href = `view-profile.html?uid=${c.peer}`;
        callList.appendChild(it);
      }
    });
}
