// ================================
// CHATS.JS — list of chats with WhatsApp-style previews
// ================================

const chatList    = document.getElementById("chatList");
const fab         = document.getElementById("fab");
const fabAI       = document.getElementById("fabAI");
const aiPin       = document.getElementById("aiPin");
const aiTime      = document.getElementById("aiTime");
const aiSnippet   = document.getElementById("aiSnippet");
const searchToggle= document.getElementById("searchToggle");
const searchBar   = document.getElementById("searchBar");
const searchInput = document.getElementById("searchInput");

if (fab)   fab.onclick   = () => location.href = "contacts.html";
if (fabAI) fabAI.onclick = () => location.href = "ai-chat.html";
if (aiPin) aiPin.onclick = () => location.href = "ai-chat.html";

if (searchToggle) searchToggle.onclick = () => {
  searchBar.hidden = !searchBar.hidden;
  if (!searchBar.hidden) searchInput.focus();
};
if (searchInput) searchInput.oninput = e => {
  const q = e.target.value.toLowerCase();
  chatList.querySelectorAll(".list-item").forEach(it=>{
    it.style.display = (it.dataset.search||"").includes(q) ? "" : "none";
  });
};

const userCache = {};
function getUser(uid){
  if (userCache[uid]) return Promise.resolve(userCache[uid]);
  return db.ref("users/"+uid).once("value").then(s=>{userCache[uid]=s.val()||{};return userCache[uid];});
}
function avatarHTML(u){
  if (u && u.photoURL) return `<img src="${u.photoURL}" alt="">`;
  return ((u&&u.name)||"?")[0].toUpperCase();
}
function fmtTime(t){
  if (!t) return "";
  const d = new Date(t), today = new Date();
  if (d.toDateString()===today.toDateString())
    return d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
  const diff = (today-d)/86400000;
  if (diff < 7) return d.toLocaleDateString([],{weekday:"short"});
  return d.toLocaleDateString([],{day:"numeric",month:"short"});
}

function previewIcon(meta){
  const t = meta.lastType || "";
  if (t==="image") return "📷 ";
  if (t==="video") return "🎥 ";
  if (t==="audio"||t==="voice") return "🎤 ";
  if (t==="doc"||t==="file") return "📎 ";
  if (t==="location") return "📍 ";
  if (t==="contact") return "👤 ";
  if (t==="call") return "📞 ";
  return "";
}
function tickHTML(meta, myUid){
  if (meta.lastFrom !== myUid) return "";
  const s = meta.lastStatus;
  if (s==="read")      return `<span class="tick read">✓✓</span>`;
  if (s==="delivered") return `<span class="tick">✓✓</span>`;
  return `<span class="tick">✓</span>`;
}

auth.onAuthStateChanged(user => {
  if (!user) return;
  db.ref("users/"+user.uid).update({online:true,lastSeen:Date.now()});

  // AI last message preview
  const aiKey = "ai_chat_"+user.uid;
  try{
    const raw = localStorage.getItem(aiKey);
    if (raw){
      const hist = JSON.parse(raw);
      if (Array.isArray(hist) && hist.length){
        const last = hist[hist.length-1];
        aiSnippet.textContent = (last.text||last.content||"").slice(0,60);
        aiTime.textContent = "";
      }
    }
  }catch(e){}

  loadChats(user);
});

function loadChats(user){
  db.ref("userChats/"+user.uid).on("value", async snap => {
    const chats = snap.val() || {};
    const entries = Object.entries(chats).sort((a,b)=>(b[1].time||0)-(a[1].time||0));
    chatList.innerHTML = "";

    if (!entries.length){
      chatList.innerHTML = `<div class="empty">No chats yet.<br>Tap + to start chatting.</div>`;
      return;
    }

    for (const [otherUid, meta] of entries){
      const u = await getUser(otherUid);
      const item = document.createElement("div");
      item.className = "list-item";
      const unread = meta.unread || 0;
      if (unread) item.classList.add("unread");
      item.dataset.search = ((u.name||"")+" "+(u.email||"")+" "+(meta.lastMessage||"")).toLowerCase();

      // typing indicator
      let snippet = "";
      if (meta.typing) snippet = `<span class="typing">typing…</span>`;
      else if (meta.draft) snippet = `<span class="draft">Draft:</span>${meta.draft}`;
      else snippet = `${tickHTML(meta, user.uid)}${previewIcon(meta)}${(meta.lastMessage||"").replace(/</g,"&lt;")}`;

      const muted = meta.muted ? `<span class="muted-ico">🔕</span>` : "";

      item.innerHTML = `
        <div class="avatar">${avatarHTML(u)}</div>
        <div class="meta">
          <div class="name">
            <span>${u.name||"User"}${u.isBusiness?" 🏢":""}</span>
            <span class="time">${fmtTime(meta.time)}</span>
          </div>
          <div class="snippet">${muted}${snippet}</div>
        </div>
        <div class="right">
          ${unread?`<span class="badge">${unread}</span>`:""}
        </div>`;
      item.onclick = () => location.href = `chat.html?uid=${otherUid}`;
      chatList.appendChild(item);
    }
  });
}

// presence ping
setInterval(()=>{
  const u = auth.currentUser; if (!u) return;
  db.ref("users/"+u.uid).update({online:true,lastSeen:Date.now()});
}, 60000);
window.addEventListener("beforeunload", ()=>{
  const u = auth.currentUser; if (!u) return;
  db.ref("users/"+u.uid).update({online:false,lastSeen:Date.now()});
});
