const list = document.getElementById("contactsList");
const search = document.getElementById("contactSearch");

auth.onAuthStateChanged(user => {
  if (!user) return;

  db.ref("users").on("value", snap => {
    const all = snap.val() || {};

    list.innerHTML = "";

    const contacts = Object.values(all)
      .filter(u => u.uid !== user.uid)
      .sort((a, b) => (a.name || "").localeCompare(b.name || ""));

    contacts.forEach(u => {

      const item = document.createElement("div");
      item.className = "list-item";

      item.dataset.search = (
        (u.name || "") + " " +
        (u.email || "") + " " +
        (u.phone || "") + " " +
        (u.bio || "")
      ).toLowerCase();

      const avatar = u.photoURL
        ? `<img src="${u.photoURL}">`
        : (u.name || "?")[0].toUpperCase();

      item.innerHTML = `
        <div class="avatar">
          ${avatar}
          <span class="online-dot ${u.online ? "online" : ""}"></span>
        </div>

        <div class="meta">

          <div class="name">
            ${u.name || "User"}
            ${u.isBusiness ? " 🏢" : ""}
          </div>

          <div class="snippet" id="last-${u.uid}">
            ${u.bio || u.email || ""}
          </div>

        </div>

        <div class="right">

          <div class="time" id="time-${u.uid}"></div>

          <div class="badge" id="badge-${u.uid}" style="display:none;">
            0
          </div>

        </div>
      `;

      item.onclick = () => {
        location.href = `chat.html?uid=${u.uid}`;
      };

      list.appendChild(item);

      const roomId =
        user.uid < u.uid
          ? `${user.uid}_${u.uid}`
          : `${u.uid}_${user.uid}`;

      db.ref(`messages/${roomId}`)
        .limitToLast(1)
        .on("child_added", s => {

          const m = s.val() || {};

          document.getElementById(`last-${u.uid}`).textContent =
            m.text ||
            (m.image ? "📷 Photo" :
            m.video ? "🎥 Video" :
            m.audio ? "🎤 Voice message" :
            m.file ? "📎 File" :
            "");

          document.getElementById(`time-${u.uid}`).textContent =
            m.time || "";

        });

      db.ref(`userChatState/${roomId}/${user.uid}`)
        .on("value", s => {

          const unread = s.val()?.unread || 0;

          const badge =
            document.getElementById(`badge-${u.uid}`);

          if (unread > 0) {
            badge.style.display = "flex";
            badge.textContent = unread;
          } else {
            badge.style.display = "none";
          }

        });

    });

    if (!contacts.length) {
      list.innerHTML =
        "<div class='empty'>No other users yet.</div>";
    }

  });

});

if (search) {

  search.addEventListener("input", () => {

    const q = search.value.toLowerCase().trim();

    list.querySelectorAll(".list-item").forEach(item => {

      item.style.display =
        item.dataset.search.includes(q)
          ? ""
          : "none";

    });

  });

}