// ================================
// GROUPS.JS
// ================================

const groupList    = document.getElementById("groupList");
const fab          = document.getElementById("newGroupFab");
const fabAI        = document.getElementById("fabAI");
const searchToggle = document.getElementById("searchToggle");
const searchBar    = document.getElementById("searchBar");
const searchInput  = document.getElementById("searchInput");

const overlay      = document.getElementById("gmOverlay");
const step1        = document.getElementById("gmStep1");
const step2        = document.getElementById("gmStep2");
const gmCancel     = document.getElementById("gmCancel");
const gmNext       = document.getElementById("gmNext");
const gmBack       = document.getElementById("gmBack");
const gmCreate     = document.getElementById("gmCreate");
const contactPicker= document.getElementById("contactPicker");
const selectedChips= document.getElementById("selectedChips");
const gmName       = document.getElementById("gmName");
const gmDesc       = document.getElementById("gmDesc");
const memberStrip  = document.getElementById("gmMemberStrip");

if (fabAI) fabAI.onclick = () => location.href = "ai-chat.html";

if (searchToggle) searchToggle.onclick = () => {
  searchBar.hidden = !searchBar.hidden;
  if (!searchBar.hidden) searchInput.focus();
};
if (searchInput) searchInput.oninput = e => {
  const q = e.target.value.toLowerCase();
  groupList.querySelectorAll(".list-item").forEach(it=>{
    it.style.display = (it.dataset.search||"").includes(q) ? "" : "none";
  });
};

const userCache = {};
function getUser(uid){
  if (userCache[uid]) return Promise.resolve(userCache[uid]);
  return db.ref("users/"+uid).once("value").then(s=>{userCache[uid]=s.val()||{};return userCache[uid];});
}
function avatarHTML(u){
  if (u && u.photoURL) return `<img src="${u.photoURL}" alt="">`;
  return ((u&&u.name)||"?")[0].toUpperCase();
}
function fmtTime(t){
  if (!t) return "";
  const d = new Date(t), today = new Date();
  if (d.toDateString()===today.toDateString())
    return d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
  return d.toLocaleDateString([],{day:"numeric",month:"short"});
}

let myUid = null;

auth.onAuthStateChanged(user => {
  if (!user) return;
  myUid = user.uid;
  loadGroups();
});

function loadGroups(){
  db.ref("userGroups/"+myUid).on("value", async snap => {
    const ids = Object.keys(snap.val()||{});
    groupList.innerHTML = "";
    if (!ids.length){
      groupList.innerHTML = `<div class="empty">No groups yet.<br>Tap + to create one.</div>`;
      return;
    }
    for (const gid of ids){
      const g = (await db.ref("groups/"+gid).once("value")).val();
      if (!g) continue;
      const item = document.createElement("div");
      item.className = "list-item";
      const memberCount = Object.keys(g.members||{}).length;
      const last = g.lastMessage || "Tap to open";
      const unread = (g.unread && g.unread[myUid]) || 0;
      item.dataset.search = ((g.name||"") + " " + last).toLowerCase();
      item.innerHTML = `
        <div class="avatar">${g.photoURL?`<img src="${g.photoURL}">`:'👥'}</div>
        <div class="meta">
          <div class="name">
            <span>${g.name||"Group"}</span>
            <span class="time">${fmtTime(g.time)}</span>
          </div>
          <div class="snippet">${last}<br><small class="group-meta">${memberCount} member${memberCount!==1?'s':''}</small></div>
        </div>
        ${unread?`<span class="badge">${unread}</span>`:''}`;
      item.onclick = () => location.href = "chat.html?gid="+gid;
      groupList.appendChild(item);
    }
  });
}

// ---------- Create group ----------
let pickerContacts = [];
const picked = new Set();

if (fab) fab.onclick = openPicker;
gmCancel.onclick = closeOverlay;
gmBack.onclick = () => { step2.hidden = true; step1.hidden = false; };
gmNext.onclick = () => {
  if (picked.size < 1){ alert("Select at least 1 member"); return; }
  renderMemberStrip();
  step1.hidden = true; step2.hidden = false;
  gmName.focus();
};
gmCreate.onclick = createGroup;

async function openPicker(){
  overlay.hidden = false;
  step1.hidden = false; step2.hidden = true;
  picked.clear(); selectedChips.innerHTML = "";
  gmName.value = ""; gmDesc.value = "";
  contactPicker.innerHTML = `<div class="empty">Loading contacts…</div>`;

  // contacts = users you've chatted with
  const chats = (await db.ref("userChats/"+myUid).once("value")).val() || {};
  pickerContacts = [];
  for (const uid of Object.keys(chats)){
    const u = await getUser(uid);
    pickerContacts.push({uid, ...u});
  }
  renderPicker();
}
function closeOverlay(){ overlay.hidden = true; }

function renderPicker(){
  contactPicker.innerHTML = "";
  if (!pickerContacts.length){
    contactPicker.innerHTML = `<div class="empty">No contacts. Start a chat first.</div>`;
    return;
  }
  pickerContacts.forEach(u => {
    const row = document.createElement("div");
    row.className = "list-item contact-row" + (picked.has(u.uid)?" selected":"");
    row.innerHTML = `
      <div class="avatar">${avatarHTML(u)}</div>
      <div class="meta">
        <div class="name"><span>${u.name||"User"}</span></div>
        <div class="snippet">${u.email||""}</div>
      </div>
      <div class="check">✓</div>`;
    row.onclick = () => {
      if (picked.has(u.uid)) picked.delete(u.uid); else picked.add(u.uid);
      row.classList.toggle("selected");
      renderChips();
    };
    contactPicker.appendChild(row);
  });
}

function renderChips(){
  selectedChips.innerHTML = "";
  picked.forEach(uid=>{
    const u = pickerContacts.find(c=>c.uid===uid) || {};
    const chip = document.createElement("div");
    chip.className = "chip";
    chip.innerHTML = `<div class="avatar">${avatarHTML(u)}</div>${u.name||"User"}<span class="x">✕</span>`;
    chip.querySelector(".x").onclick = ev => {
      ev.stopPropagation();
      picked.delete(uid);
      renderChips(); renderPicker();
    };
    selectedChips.appendChild(chip);
  });
}

function renderMemberStrip(){
  memberStrip.innerHTML = "";
  picked.forEach(uid=>{
    const u = pickerContacts.find(c=>c.uid===uid) || {};
    const a = document.createElement("div");
    a.className = "avatar";
    a.innerHTML = avatarHTML(u);
    memberStrip.appendChild(a);
  });
}

async function createGroup(){
  const name = gmName.value.trim();
  if (!name){ alert("Enter a group name"); gmName.focus(); return; }
  const desc = gmDesc.value.trim();
  const ref  = db.ref("groups").push();
  const gid  = ref.key;
  const members = {[myUid]:true};
  const admins  = {[myUid]:true};
  picked.forEach(u => members[u]=true);

  const data = {
    id: gid,
    name, description: desc,
    createdBy: myUid,
    createdAt: Date.now(),
    time: Date.now(),
    lastMessage: "Group created",
    members, admins
  };
  await ref.set(data);

  const updates = {};
  Object.keys(members).forEach(uid => {
    updates[`userGroups/${uid}/${gid}`] = true;
  });
  await db.ref().update(updates);

  // System message
  await db.ref("groupMessages/"+gid).push({
    type:"system", text:`${(await getUser(myUid)).name||"You"} created group "${name}"`,
    time: Date.now()
  });

  closeOverlay();
  location.href = "chat.html?gid="+gid;
}
