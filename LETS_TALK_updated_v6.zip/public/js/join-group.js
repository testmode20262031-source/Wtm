// Join group via invite link
const params = new URLSearchParams(location.search);
const gid = params.get('gid');
const token = params.get('t');
const err = document.getElementById('err');
const joinBtn = document.getElementById('joinBtn');

function showErr(msg){ err.textContent = msg; err.classList.add('show'); joinBtn.disabled = true; joinBtn.style.opacity=.5; }

if (!gid || !token) showErr('Invalid invite link.');

let me = null, group = null;

auth.onAuthStateChanged(async u => {
  if (!u) return;
  me = u;
  if (!gid || !token) return;
  const snap = await db.ref('groups/'+gid).once('value');
  group = snap.val();
  if (!group) return showErr('Group not found.');
  if (!group.invite || group.invite.token !== token) return showErr('This invite link has expired or was revoked.');

  document.getElementById('gName').textContent = group.name || 'Group';
  if (group.photoURL) document.getElementById('gAvatar').innerHTML = `<img src="${group.photoURL}"/>`;
  else document.getElementById('gAvatar').textContent = (group.name||'G')[0].toUpperCase();
  const n = Object.keys(group.members||{}).length;
  document.getElementById('gSub').textContent = 'Group · ' + n + ' member' + (n===1?'':'s');
  document.getElementById('gDesc').textContent = group.description || '';

  if (group.members && group.members[me.uid]) {
    joinBtn.textContent = 'Open chat';
    joinBtn.onclick = () => location.href = 'chat.html?gid='+gid;
    return;
  }

  joinBtn.onclick = async () => {
    joinBtn.disabled = true;
    await db.ref('groups/'+gid+'/members/'+me.uid).set(true);
    await db.ref('userGroups/'+me.uid+'/'+gid).set(true);
    const u2 = (await db.ref('users/'+me.uid).once('value')).val() || {};
    await db.ref('messages/'+'group_'+gid).push({
      from: 'system', time: Date.now(), type:'system',
      text: (u2.name || 'A user') + ' joined via invite link'
    });
    location.href = 'chat.html?gid=' + gid;
  };
});
