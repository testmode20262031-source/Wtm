let me = null, currentData = {};

auth.onAuthStateChanged(user => {
  if (!user) return;
  me = user;
  db.ref('users/' + user.uid).once('value').then(s => {
    currentData = s.val() || {};
    document.getElementById('name').value = currentData.name || '';
    document.getElementById('bio').value = currentData.bio || '';
    document.getElementById('isBusiness').checked = !!currentData.isBusiness;
    document.getElementById('bizWrap').style.display = currentData.isBusiness?'':'none';
    if (currentData.photoURL) document.getElementById('avatarPreview').innerHTML = `<img src="${currentData.photoURL}"/>`;
    if (currentData.businessDp) document.getElementById('bizPreview').innerHTML = `<img src="${currentData.businessDp}"/>`;
  });
});

document.getElementById('isBusiness').addEventListener('change', e => {
  document.getElementById('bizWrap').style.display = e.target.checked?'':'none';
});

async function uploadImg(file, path) {
  const ref = storage.ref(path);
  await ref.put(file);
  return ref.getDownloadURL();
}

document.getElementById('photoInput').addEventListener('change', async e => {
  const f = e.target.files[0]; if (!f) return;
  const url = await uploadImg(f, 'avatars/' + me.uid + '.jpg');
  currentData.photoURL = url;
  document.getElementById('avatarPreview').innerHTML = `<img src="${url}"/>`;
});
document.getElementById('bizInput').addEventListener('change', async e => {
  const f = e.target.files[0]; if (!f) return;
  const url = await uploadImg(f, 'business/' + me.uid + '.jpg');
  currentData.businessDp = url;
  document.getElementById('bizPreview').innerHTML = `<img src="${url}"/>`;
});

document.getElementById('profileForm').addEventListener('submit', async e => {
  e.preventDefault();
  const update = {
    name: document.getElementById('name').value.trim(),
    bio: document.getElementById('bio').value.trim(),
    isBusiness: document.getElementById('isBusiness').checked,
    photoURL: currentData.photoURL || '',
    businessDp: currentData.businessDp || ''
  };
  await db.ref('users/' + me.uid).update(update);
  await me.updateProfile({ displayName: update.name, photoURL: update.photoURL });
  alert('Saved!');
  location.href = 'settings.html';
});
