const form = document.getElementById('signupForm');
const err = document.getElementById('err');

form.addEventListener('submit', async e => {
  e.preventDefault();
  err.classList.remove('show');
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const pass = document.getElementById('password').value;
  try {
    const cred = await auth.createUserWithEmailAndPassword(email, pass);
    await cred.user.updateProfile({ displayName: name });
    await db.ref('users/' + cred.user.uid).set({
      uid: cred.user.uid,
      name, email,
      bio: 'Hey there! I am using LET\'S TALK.',
      photoURL: '',
      isBusiness: false,
      businessDp: '',
      createdAt: firebase.database.ServerValue.TIMESTAMP
    });
    location.href = 'home.html';
  } catch (ex) {
    err.textContent = ex.message;
    err.classList.add('show');
  }
});
