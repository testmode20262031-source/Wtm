// Wait briefly then route based on auth
setTimeout(() => {
  auth.onAuthStateChanged(user => {
    location.href = user ? 'pages/home.html' : 'pages/login.html';
  });
}, 1800);
