// ================================
// STATUS-VIEW.JS
// ================================

const params = new URLSearchParams(location.search);
const targetUid = params.get("uid");

const elProg   = document.getElementById("svProgress");
const elAvatar = document.getElementById("svAvatar");
const elName   = document.getElementById("svName");
const elTime   = document.getElementById("svTime");
const elText   = document.getElementById("svText");
const elImage  = document.getElementById("svImage");
const elVideo  = document.getElementById("svVideo");
const elPrev   = document.getElementById("svPrev");
const elNext   = document.getElementById("svNext");
const elReact  = document.getElementById("svReact");
const elReply  = document.getElementById("svReply");
const elSend   = document.getElementById("svSend");
const elView   = document.getElementById("svViewers");
const elCount  = document.getElementById("svViewCount");
const vp       = document.getElementById("viewersPanel");
const vpClose  = document.getElementById("vpClose");
const vpList   = document.getElementById("vpList");
const svMore   = document.getElementById("svMore");

let items = [];        // [ {key, ...status} ]
let idx   = 0;
let myUid = null;
let timer = null;
let isMine = false;

const userCache = {};
function getUser(uid){
  if (userCache[uid]) return Promise.resolve(userCache[uid]);
  return db.ref("users/"+uid).once("value").then(s=>{userCache[uid]=s.val()||{};return userCache[uid];});
}
function avatarHTML(u){
  if (u.photoURL) return `<img src="${u.photoURL}" alt="">`;
  return (u.name||"?")[0].toUpperCase();
}
function fmtTime(t){
  const m = Math.floor((Date.now()-t)/60000);
  if (m<1) return "just now";
  if (m<60) return m+"m ago";
  return Math.floor(m/60)+"h ago";
}

auth.onAuthStateChanged(async user => {
  if (!user || !targetUid) { location.href="status.html"; return; }
  myUid = user.uid;
  isMine = (myUid === targetUid);

  const u = await getUser(targetUid);
  elAvatar.innerHTML = avatarHTML(u);
  elName.textContent = isMine ? "My status" : (u.name || "User");

  const snap = await db.ref("status/"+targetUid).once("value");
  const now = Date.now();
  items = Object.entries(snap.val()||{})
    .map(([k,v])=>({key:k,...v}))
    .filter(s => (now - s.time) < 24*60*60*1000)
    .sort((a,b)=>a.time-b.time);

  if (!items.length){ location.href="status.html"; return; }

  // Build progress segments
  elProg.innerHTML = items.map(()=>`<div class="seg"><span class="bar"></span></div>`).join("");

  idx = 0;
  if (isMine) {
    elReact.style.display = "none";
    elReply.style.display = "none";
    elSend.style.display  = "none";
    elView.hidden = false;
  }
  show();
});

function clearTimer(){ if (timer){ clearTimeout(timer); timer=null; } }

async function show(){
  clearTimer();
  if (idx < 0) { history.back(); return; }
  if (idx >= items.length){ history.back(); return; }

  // reset bars
  [...elProg.querySelectorAll(".bar")].forEach((b,i)=>{
    b.style.transition = "none";
    b.style.width = i<idx ? "100%" : "0%";
  });

  const s = items[idx];
  elTime.textContent = fmtTime(s.time);

  elText.hidden = elImage.hidden = elVideo.hidden = true;
  elImage.src = ""; elVideo.src = "";

  let duration = 5000;
  if (s.type === "text") {
    elText.textContent = s.text || "";
    elText.style.background = s.bg || "#075e54";
    elText.hidden = false;
  } else if (s.type === "image") {
    elImage.src = s.url; elImage.hidden = false;
  } else if (s.type === "video") {
    elVideo.src = s.url; elVideo.hidden = false;
    elVideo.play().catch(()=>{});
    duration = 15000;
  }

  // Mark viewed
  if (!isMine && myUid) {
    db.ref(`status/${targetUid}/${s.key}/views/${myUid}`).set(Date.now());
  }
  if (isMine) {
    const c = s.views ? Object.keys(s.views).length : 0;
    elCount.textContent = c;
  }

  // animate current bar
  const bar = elProg.querySelectorAll(".bar")[idx];
  requestAnimationFrame(()=>{
    bar.style.transition = `width ${duration}ms linear`;
    bar.style.width = "100%";
  });

  timer = setTimeout(()=>{ idx++; show(); }, duration);
}

elPrev.onclick = () => { idx--; show(); };
elNext.onclick = () => { idx++; show(); };

// Reactions
elReact.querySelectorAll("button").forEach(b=>{
  b.onclick = async () => {
    const r = b.dataset.r;
    const s = items[idx];
    // send as chat message to that user
    if (!myUid || isMine) return;
    const chatId = [myUid,targetUid].sort().join("_");
    await db.ref("messages/"+chatId).push({
      from: myUid, to: targetUid,
      type: "status-reaction",
      text: r,
      statusRef: s.key,
      statusType: s.type,
      statusPreview: s.type==="text"?(s.text||"").slice(0,40):"[media]",
      time: Date.now()
    });
    await db.ref(`userChats/${myUid}/${targetUid}`).update({lastMessage:"Reacted "+r+" to status", time:Date.now()});
    await db.ref(`userChats/${targetUid}/${myUid}`).update({lastMessage:"Reacted "+r+" to your status", time:Date.now()});
    flash("Reaction sent");
  };
});

elSend.onclick = async () => {
  const txt = elReply.value.trim();
  if (!txt || isMine || !myUid) return;
  const s = items[idx];
  const chatId = [myUid,targetUid].sort().join("_");
  await db.ref("messages/"+chatId).push({
    from: myUid, to: targetUid,
    type: "status-reply",
    text: txt,
    statusRef: s.key,
    statusType: s.type,
    statusPreview: s.type==="text"?(s.text||"").slice(0,40):"[media]",
    time: Date.now()
  });
  await db.ref(`userChats/${myUid}/${targetUid}`).update({lastMessage:"↩ "+txt, time:Date.now()});
  await db.ref(`userChats/${targetUid}/${myUid}`).update({lastMessage:"↩ Reply to status: "+txt, time:Date.now(),unread:firebase.database.ServerValue.increment ? firebase.database.ServerValue.increment(1) : 1});
  elReply.value = "";
  flash("Reply sent");
};

elReply.addEventListener("focus", ()=>clearTimer());
elReply.addEventListener("blur",  ()=>{ if(!isMine) show(); });

// Viewers panel (mine only)
elView.onclick = async () => {
  const s = items[idx];
  vpList.innerHTML = "";
  const v = s.views || {};
  const uids = Object.keys(v).sort((a,b)=>v[b]-v[a]);
  if (!uids.length){
    vpList.innerHTML = `<div class="empty">No viewers yet</div>`;
  } else {
    for (const uid of uids){
      const u = await getUser(uid);
      const div = document.createElement("div");
      div.className = "list-item";
      div.innerHTML = `
        <div class="avatar">${avatarHTML(u)}</div>
        <div class="meta">
          <div class="name"><span>${u.name||"User"}</span></div>
          <div class="snippet">${fmtTime(v[uid])}</div>
        </div>`;
      vpList.appendChild(div);
    }
  }
  vp.hidden = false;
  clearTimer();
};
vpClose.onclick = () => { vp.hidden = true; show(); };

// Long-press delete (mine)
svMore.onclick = async () => {
  if (!isMine){ alert("Status auto-expires in 24 hours."); return; }
  if (!confirm("Delete this status update?")) return;
  const s = items[idx];
  await db.ref(`status/${myUid}/${s.key}`).remove();
  items.splice(idx,1);
  if (!items.length) { history.back(); return; }
  if (idx >= items.length) idx = items.length-1;
  elProg.innerHTML = items.map(()=>`<div class="seg"><span class="bar"></span></div>`).join("");
  show();
};

function flash(t){
  const d = document.createElement("div");
  d.textContent = t;
  d.style.cssText = "position:fixed;left:50%;bottom:120px;transform:translateX(-50%);background:rgba(0,0,0,.8);color:#fff;padding:8px 14px;border-radius:20px;z-index:9999;font-size:.9rem";
  document.body.appendChild(d);
  setTimeout(()=>d.remove(),1500);
}
