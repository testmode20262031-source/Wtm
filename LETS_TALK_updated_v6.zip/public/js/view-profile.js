const uid = new URLSearchParams(location.search).get('uid');
db.ref('users/' + uid).once('value').then(s => {
  const u = s.val() || {};
  document.getElementById('vName').textContent = u.name || 'User';
  document.getElementById('vBio').textContent = u.bio || '—';
  document.getElementById('vEmail').textContent = u.email || '';
  document.getElementById('vAvatar').innerHTML = u.photoURL?`<img src="${u.photoURL}"/>`:(u.name||'?')[0];
  if (u.isBusiness) {
    document.getElementById('vBiz').innerHTML =
      `<div style="background:#fff3e6;padding:12px;border-radius:8px">
        🏢 <b>Business account</b>
        ${u.businessDp?`<div style="margin-top:8px"><img src="${u.businessDp}" style="max-width:140px;border-radius:8px"/></div>`:''}
      </div>`;
  }
});
db.ref('status/' + uid).on('value', s => {
  const v = s.val(); if (!v) return;
  document.getElementById('vStatus').textContent =
    v.state==='online' ? 'online' : 'last seen ' + new Date(v.last_changed).toLocaleString();
});
document.getElementById('msgBtn').onclick = () => location.href = 'chat.html?uid=' + uid;
