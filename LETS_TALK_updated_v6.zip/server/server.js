// LET'S TALK - AI backend
// Lightweight Express server that proxies chat requests to Google Gemini
// and (optionally) serves the static PWA from ../public.

import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

import aiRouter from "./routes/ai.js";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();

app.use(cors());
app.use(express.json({ limit: "1mb" }));

// --- API ----------------------------------------------------
app.get("/", (_req, res) => {
  res.send("LET'S TALK AI server is running.");
});

app.use("/api/chat", aiRouter);

// --- Optional: serve the static frontend --------------------
// Lets you host the whole app from one origin in production.
// Set SERVE_STATIC=1 in .env to enable.
if (process.env.SERVE_STATIC === "1") {
  const pub = path.resolve(__dirname, "../public");
  app.use(express.static(pub));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(pub, "index.html"));
  });
}

// --- Boot ---------------------------------------------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`LET'S TALK AI server listening on http://localhost:${PORT}`);
  if (!process.env.GEMINI_API_KEY) {
    console.warn("⚠️  GEMINI_API_KEY missing - /api/chat will return 500.");
  }
});
