// Gemini service wrapper
// Centralizes all calls to Google Generative AI so the rest of the
// server (and any future tools) can stay model-agnostic.

import { GoogleGenAI } from "@google/genai";

const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

const SYSTEM_PROMPT = `
You are "LET'S TALK AI", the in-app assistant for the LET'S TALK messaging app.
Be warm, concise, and helpful. Use short paragraphs and the user's language.
If the user asks something you cannot answer, say so honestly.
`.trim();

let _ai = null;
function client() {
  if (_ai) return _ai;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set in environment");
  }
  _ai = new GoogleGenAI({ apiKey });
  return _ai;
}

/**
 * Generate a reply for a conversation.
 * @param {Array<{role:'user'|'model'|'assistant', text:string}>} history
 *   Past turns, oldest first. The latest user message MUST be the last entry.
 * @returns {Promise<string>} model reply text
 */
export async function chat(history) {
  if (!Array.isArray(history) || history.length === 0) {
    throw new Error("history must be a non-empty array");
  }

  // Normalize roles: Gemini expects 'user' or 'model'
  const contents = history.map((turn) => ({
    role: turn.role === "assistant" ? "model" : (turn.role || "user"),
    parts: [{ text: String(turn.text ?? "") }],
  }));

  const response = await client().models.generateContent({
    model: MODEL,
    contents,
    config: {
      systemInstruction: SYSTEM_PROMPT,
      temperature: 0.7,
    },
  });

  return (response?.text || "").trim() || "…";
}

/** Convenience: single-shot prompt without history. */
export function ask(message) {
  return chat([{ role: "user", text: message }]);
}
